from django.apps import AppConfig


class PlistConfig(AppConfig):
    name = 'plist'
